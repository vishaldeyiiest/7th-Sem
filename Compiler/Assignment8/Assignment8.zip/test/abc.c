{
	/*int b, c;
	int a = b*-c;
	while(c)
	{
		if((a = b) < c)
			b += b*c + b/(a+c*10);
		else
			c++;	
	}*/
	int a, b, c, d, x, y, z;
	a = (c - d) + b + 10;
	
	if(a < 200)
		a = c - (x+145);
	else
		a = c++;
	/*	
	while(y < x)
	{
		if(a < c) 
			a = 200;
		else
			a--;
	}
	z = 10;
	*/
	
}
